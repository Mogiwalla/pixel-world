BREAK = 0
PLACE = 1
GENERATE_WORLD = 2
CREATE_WORLD = 3
COPY = 4
PAST = 5
NB_EVENTS = 6

# const contain elements of world
VOID = 0
GRASS = 1
DIRT = 2
STONE = 3
TRUNK = 4
LEAF = 5

CABLE = 6
POWERED_CABLE = -6
CHARGER = 7

OR = 8
POWERED_OR = -8

AND = 9
POWERED_AND = -9

NOT = 10
POWERED_NOT = -10

XOR = 11
POWERED_XOR = -11

BRIDGE = 12
BRIDGE_ON_OFF = -112 # vertical is on, horizontal is off
BRIDGE_OFF_ON = -113
BRIDGE_ON_ON  = -114

PLANKS = 13
SIGN = 14
LAST_ID = SIGN

def place_square(world, line, column, square_id, signs, farmings):
    if line >= 0 and line < 100 and column >= 0 and column < len(world[0]):
        if world[line][column] == SIGN and (line, column) in signs:
            del signs[(line, column)]
        world[line][column] = square_id

class Mod:
    def __init__(self):
        def not_func(world: list, cursor_start = None, cursor_end = None):
            pass

        self.have_event = [False for _ in range(NB_EVENTS)]
        self.event_func = [not_func for _ in range(NB_EVENTS)]
        self.squares = []

    def add_event(self, event: int, func):
        if self.have_event[event]:
            raise ValueError("event already defined")
        
        self.have_event[event] = True
        self.event_func = func

    def add_square(self, name: str | None = None):
        if self.squares < 36:
            self.squares.append(name)
            return LAST_ID + len(self.squares)
        return "you are limited to 36 squares"