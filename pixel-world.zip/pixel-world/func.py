from random import randint
import pygame
from pygame import gfxdraw
import pickle
import os
import urllib.request
import zipfile
import shutil
from collections import deque
from tools import *
import importlib.util
from pathlib import Path

pygame.init()

version = "3.0.1"
with open("textures/classic/version.txt", "r") as file:
    textures_version = file.read()
URL_TEXTURES_VERSION = "https://mogiwalla.github.io/pixel-world/textures_version.txt"
URL_VERSION          = "https://mogiwalla.github.io/pixel-world/version.txt"
URL_TEXTURES         = "https://mogiwalla.github.io/pixel-world/textures.zip"
URL_GAME             = "https://mogiwalla.github.io/pixel-world/pixel-world.zip"

w = 800
h = 600
square_size = w//15
title_window = "pixel world: "
LEFT_CLICK = 1
RIGHT_CLICK = 3

SOURCES = (CHARGER, POWERED_CABLE)
POWERED_DOORS = (POWERED_AND, POWERED_OR, POWERED_XOR, POWERED_NOT)
BRIDGES = (BRIDGE, BRIDGE_OFF_ON, BRIDGE_ON_OFF, BRIDGE_ON_ON)
POWERED_BRIDGES_H = (BRIDGE_ON_ON, BRIDGE_OFF_ON)
POWERED_BRIDGES_V = (BRIDGE_ON_ON, BRIDGE_ON_OFF)

def draw(window, mod, textures, colors_of_squares, world, column_started, column_finish, line_started, line_finish, cam, sign_texts, font):
    for column in range(column_started, column_finish):
        for line in range(line_started, line_finish):
            current_id = world[line][column]
            if current_id != VOID:
                square_pos = (column*square_size - cam.x, line*square_size - cam.y)
                current_square = pygame.Rect(square_pos, (square_size, square_size))
                if current_id <= LAST_ID:
                    if textures[current_id] != None:
                        window.blit(textures[current_id], current_square)
                    else:
                        current_color = colors_of_squares[current_id]
                        pygame.draw.rect(window, current_color, current_square)

                    if current_id == SIGN and (line, column) in sign_texts:
                        sign_txt = font.render(sign_texts[(line, column)], True, (255,255,255))
                        txt_pos = (square_pos[0]+square_size/2-sign_txt.get_width()/2,
                                   square_pos[1]+square_size/3-sign_txt.get_height()/2)
                        window.blit(sign_txt, txt_pos)
                else:
                    if len(mod.squares) > current_id-LAST_ID-1:
                        square = mod.squares[current_id-LAST_ID-1]
                        if (square in textures) and (textures[square] != None):
                            window.blit(textures[square], current_square)
                        else:
                            pygame.draw.rect(window, (255,0,255), current_square)
                    else:
                        pygame.draw.rect(window, (255,0,255), current_square)

def execute_mod_event(event, mod, world, cursor_start = None, cursor_end = None):
    if mod.have_event[event]:
        mod.event_func(world, cursor_start, cursor_end)

def load_mod(name, textures):
    path = Path(__file__).parent / name / "main.py"
    spec = importlib.util.spec_from_file_location("mod", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    if "textures" in os.listdir(name):
        mod_textures = os.listdir(name+"/textures")
        for square in mod.mod.squares:
            textures[square] = load_texture(name+"/textures", mod_textures, square+".png", square_size)
    return mod.mod

def textures_update():
    urllib.request.urlretrieve(URL_TEXTURES, "download.zip")
    os.makedirs("download", exist_ok=True)
    with zipfile.ZipFile("download.zip", "r") as file:
        file.extractall("download")
    os.remove("download.zip")
    for texture in os.listdir("download/classic"):
        shutil.move("download/classic/"+texture, "textures/classic/"+texture)
    shutil.rmtree("download")

def have_update(URL, version):
    try:
        with urllib.request.urlopen(URL, timeout=10) as file:
            new_version = file.read().decode("utf-8")
            return new_version != version
    except:
        print("page not found")
        return False

def update():
    urllib.request.urlretrieve(URL_GAME, "download.zip")
    os.makedirs("download", exist_ok=True)
    with zipfile.ZipFile("download.zip", "r") as file:
        file.extractall("download")
    os.remove("download.zip")
    shutil.move("download/pixel-world/func.py", "func.py")
    shutil.move("download/pixel-world/start.py", "start.py")
    shutil.move("download/pixel-world/tools.py", "tools.py")
    shutil.rmtree("download")

def power_from_left(world, line, column):
    if -1 < line < 100 and -1 < column:
        current_square = world[line][column-1]
        return current_square in SOURCES or (
               current_square in POWERED_DOORS or(
               current_square in POWERED_BRIDGES_H))
    return False

def power_from_right(world, line, column):
    if -1 < line < 100 and -1 < column:
        current_square = world[line][column+1]
        return current_square in SOURCES or(
               current_square in POWERED_BRIDGES_H)
    return False

def power_from_top(world, line, column):
    if -1 < line < 100 and -1 < column:
        current_square = world[line-1][column]
        return current_square in SOURCES or(
               current_square in POWERED_BRIDGES_V)
    return False

def power_from_bottom(world, line, column):
    if -1 < line < 100 and -1 < column:
        current_square = world[line+1][column]
        return current_square in SOURCES or(
               current_square in POWERED_BRIDGES_V)
    return False

def execute_elecity(world, column_started, column_finish, line_started, line_finish):
    for line in range(line_started, line_finish):
        for column in range(column_started, column_finish):
            if world[line][column] == POWERED_CABLE:
                world[line][column] = CABLE
            elif world[line][column] == POWERED_OR:
                world[line][column] = OR
            elif world[line][column] == POWERED_AND:
                world[line][column] = AND
            elif world[line][column] in BRIDGES:
                world[line][column] = BRIDGE

    screen = []
    for line in range(line_started, line_finish):
        for column in range(column_started, column_finish):
            screen.append((line, column))

    wait = deque(screen) # FIFO data

    while wait: # while not wait is empty
        line, column = wait.popleft()
        square = world[line][column]
        new_square = square

        left  = power_from_left(world, line, column)
        right = power_from_right(world, line, column)
        top = power_from_top(world, line, column)
        bottom = power_from_bottom(world, line, column)

        if square == CABLE:
            if left or right or top or bottom:
                new_square = POWERED_CABLE
        elif square in BRIDGES:
            horizontal = left or right
            vertical = top or bottom

            if horizontal and vertical:
                new_square = BRIDGE_ON_ON
            elif horizontal:
                new_square = BRIDGE_OFF_ON
            elif vertical:
                new_square = BRIDGE_ON_OFF
        elif square == OR:
            if top or bottom:
                new_square = POWERED_OR
        elif square == AND:
            if top and bottom:
                new_square = POWERED_AND

        if new_square != square:
            world[line][column] = new_square
            neighbours = ((line, column-1), (line, column+1),
                          (line-1, column), (line+1, column))
            for n_line, n_column in neighbours:
                if n_line < 100 and n_line >= 0 and n_column >= 0:
                    if (n_line, n_column) not in wait:
                        wait.append((n_line, n_column))

    for line, column in screen:
        square = world[line][column]
        if square in (NOT, POWERED_NOT):
            new_square = NOT if power_from_left(world, line, column) else POWERED_NOT
            world[line][column] = new_square
        elif square in (XOR, POWERED_XOR):
            on = power_from_top(world, line, column) != power_from_bottom(world, line, column)
            new_square = POWERED_XOR if on else XOR
            world[line][column] = new_square

def get_worlds():
    """
    return names of files in worlds directory
    """
    return os.listdir("worlds")

def get_textures_packs():
    """
    return names of directorys in textures directory
    """
    return os.listdir("textures")

def get_mods():
    """
    return names of directorys in mods directory
    """
    return os.listdir("mods")

def delete_world(worlds, i):
    os.remove("worlds/"+worlds[i])
    worlds.pop(i)

def load_texture(dir, list_textures, img, resize):
    if img in list_textures:
        texture = pygame.image.load(dir+"/"+img)
        return pygame.transform.scale(texture, (resize, resize))
    else:
        return None
    

def load_textures(pack, square_size):
    dir = "textures/"+pack
    list_textures = os.listdir(dir)
    button = load_texture(dir, list_textures, "button.png", square_size)
    if button != None:
        button = pygame.transform.scale(button, (w/4, (2*h+h/6)/15))
    return {
        GRASS: load_texture(dir, list_textures, "grass.png", square_size),
        DIRT: load_texture(dir, list_textures, "dirt.png", square_size),
        STONE: load_texture(dir, list_textures, "stone.png", square_size),
        TRUNK: load_texture(dir, list_textures, "trunk.png", square_size),
        LEAF: load_texture(dir, list_textures, "leaf.png", square_size),
        CABLE: load_texture(dir, list_textures, "cable.png", square_size),
        POWERED_CABLE: load_texture(dir, list_textures, "powered cable.png", square_size),
        OR: load_texture(dir, list_textures, "or.png", square_size),
        AND: load_texture(dir, list_textures, "and.png", square_size),
        NOT: load_texture(dir, list_textures, "not.png", square_size),
        POWERED_OR: load_texture(dir, list_textures, "powered or.png", square_size),
        POWERED_AND: load_texture(dir, list_textures, "powered and.png", square_size),
        POWERED_NOT: load_texture(dir, list_textures, "powered not.png", square_size),
        XOR: load_texture(dir, list_textures, "xor.png", square_size),
        POWERED_XOR: load_texture(dir, list_textures, "powered xor.png", square_size),
        BRIDGE: load_texture(dir, list_textures, "bridge.png", square_size),
        BRIDGE_OFF_ON: load_texture(dir, list_textures, "bridge off on.png", square_size),
        BRIDGE_ON_OFF: load_texture(dir, list_textures, "bridge on off.png", square_size),
        BRIDGE_ON_ON: load_texture(dir, list_textures, "bridge on on.png", square_size),
        CHARGER: load_texture(dir, list_textures, "charger.png", square_size),
        PLANKS: load_texture(dir, list_textures, "planks.png", square_size),
        SIGN: load_texture(dir, list_textures, "sign.png", square_size),
        "title": load_texture(dir, list_textures, "title.png", w//5),
        "delete": load_texture(dir, list_textures, "delete.png", h/15),
        "back": load_texture(dir, list_textures, "back.png", h/15),
        "button": button
    }

def have_account():
    return "account.pkl" in os.listdir()

def save_account(azerty, play_time, succes):
    """
    save account datas
    """
    with open("account.pkl", "wb") as file:
        pickle.dump((azerty, play_time, succes), file)

def load_account():
    """
    return account datas
    """
    with open("account.pkl", "rb") as file:
        datas = pickle.load(file)
    return datas

def save(name, world, cam, signs, farmings):
    """
    save the world name, the world and cam to a pickle file
    """
    with open(f"worlds/{name}.pkl", "wb") as file:
        pickle.dump((name, world, cam, signs, farmings), file)

def load(name):
    """
    return the world name, the world and cam to a pickle file
    """
    with open(f"worlds/{name}", "rb") as file:
        datas = pickle.load(file)
    return datas

def create_tree(column, world):
    """
    create and place a new tree to the world
    """
    # recover line of grass
    line = 0
    for l in range(100): # the world have 100 squares of heights
        if world[l][column] == GRASS:
            line = l
            break

    len_trunk = randint(3, 5)
    for i in range(1, len_trunk):
        world[line-i][column] = TRUNK

    for c in range(column-2, column+3):
        if world[line-len_trunk][c] == VOID:
            world[line-len_trunk][c] = LEAF

    for c in range(column-1, column+2):
        if world[line-len_trunk-1][c] == VOID:
            world[line-len_trunk-1][c] = LEAF


def create_world(mod):
    """
    return a list of list of int and line above the line of the first grass.
    int is a element of world
    """

    first_grass = None
    last_tree = 0
    shift_tree = randint(2, 8)

    # the world have 100 squares of heights
    world = [[] for _ in range(100)]

    # the world have 100 squares of weight in start
    line = 50
    depth = 5
    for column in range(100):
        line = randint(line-3, line+3)
        while line > 85:
            line = randint(line-4,line-2)

        depth = randint(depth-1, depth+1)
        if depth < 1:
            depth += 1
        
        # place voids of this column
        for i in range(line-1):
            world[i].append(VOID)

        # place grass of this column
        world[line-1].append(GRASS)
        if first_grass == None:
            first_grass = line-1

        # place dirts of this column
        for i in range(depth):
            world[line+i].append(DIRT)

        # place stones of this column
        for i in range(line+depth, 100):
            world[i].append(STONE)

        if column == last_tree + shift_tree + 5:
            create_tree(column-3, world)
            shift_tree = randint(2, 8)
            last_tree = column-3

    execute_mod_event(CREATE_WORLD, mod, world)

    return world, first_grass-1

def generate(world, size, mod):
    """
    generate a continuation of the world
    """

    # recover depth and line of dirts
    depth = 0
    l = 0
    while world[l][-1] != STONE:
        if world[l][-1] == DIRT:
            depth += 1
        l += 1
    line = l - depth

    last_tree = len(world[0])
    shift_tree =randint(2, 8)

    for _ in range(size):
        line = randint(line-3, line+3)
        while line > 85:
            line = randint(line-4,line-2)

        depth = randint(depth-1, depth+1)
        if depth < 1:
            depth += 1
        
        # place voids of this column
        for i in range(line-1):
            world[i].append(VOID)

        # place grass of this column
        world[line-1].append(GRASS)

        # place dirts of this column
        for i in range(depth):
            world[line+i].append(DIRT)

        # place stones of this column
        for i in range(line+depth, 100):
            world[i].append(STONE)

        column = len(world[0])
        if column == last_tree + shift_tree + 4:
            create_tree(column-4, world)
            shift_tree = randint(2, 8)
            last_tree = column-3

    execute_mod_event(GENERATE_WORLD, mod, world)

class Player:
    def __init__(self, line, square_size, speed):
        self.line = line
        self.column = 0
        self.x = 0
        self.y = line*square_size
        self.speed = speed

    # move and update the position
    def update(self, delta_time, square_size, world, render_distance, azerty, keys):
        move = int(self.speed*delta_time)

        if not azerty:
            if keys[pygame.K_w]:
                self.y -= move

            if keys[pygame.K_a]:
                self.x -= move
        else:
            if keys[pygame.K_z]:
                self.y -= move

            if keys[pygame.K_q]:
                self.x -= move

        if keys[pygame.K_s]:
            self.y += move

        if keys[pygame.K_d]:
            self.x += move

        self.line = self.y//square_size
        self.column = self.x//square_size

        if self.column < 0:
            self.x += move

        if self.line < 0:
            self.y += move
        elif self.line > 84:
            self.y -= move

        if self.column + render_distance//2 > len(world[0]):
            generate(world, 50)

class Button:
    def __init__(self, x, y, w, h, text, font):
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.square = pygame.Rect(x, y, w, h)
        self.text = font.render(text, True, (0,0,0))
        self.text_pos = (self.square.x+(self.square.w-self.text.get_width())/2,
                         self.square.y+(self.square.h-self.text.get_height())/2)

    def collidepoint(self, cursor):
        return self.square.collidepoint(cursor)

    def draw(self, textures, window):
        if textures["button"] != None:
            window.blit(textures["button"], self.square)
        else:
            pygame.draw.rect(window, (200,200,200), self.square)
        window.blit(self.text, self.text_pos)

class SwitchButton:
    def __init__(self, x, y, w, h, text, text2, font):
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.square    = pygame.Rect(x, y, w, h)
        self.text      = font.render(text, True, (0,0,0))
        self.text2     = font.render(text2, True, (0,0,0))
        self.text_pos  = (self.square.x+(self.square.w-self.text.get_width())/2,
                         self.square.y+(self.square.h-self.text.get_height())/2)
        self.text_pos2 = (self.square.x+(self.square.w-self.text2.get_width())/2,
                         self.square.y+(self.square.h-self.text2.get_height())/2)
        self.condition = False

    def collidepoint(self, cursor):
        return self.square.collidepoint(cursor)

    def switch(self):
        self.condition = not self.condition

    def draw(self, textures, window):
        if textures["button"] != None:
            window.blit(textures["button"], self.square)
        else:
            pygame.draw.rect(window, (200,200,200), self.square)
        if self.condition:
            window.blit(self.text2, self.text_pos2)
        else:
            window.blit(self.text, self.text_pos)