from func import *
    
######## INIT DATAS ###########
window = pygame.display.set_mode((w, h))
render_distance = 25

clock = pygame.time.Clock()
font = pygame.font.SysFont("arial", 17)
credits = (font.render("Textures:", True, (255,255,255)),
           font.render("    -Ptiteo", True, (255,255,255)),
           font.render("    -Mogi", True, (255,255,255)),
           font.render("Games designs:", True, (255,255,255)),
           font.render("    -Mogi", True, (255,255,255)),
           font.render("    -Ptiteo", True, (255,255,255)),
           font.render("Developer:", True, (255,255,255)),
           font.render("    -Mogi", True, (255,255,255)))
texture_pack_name = "classic"
textures = load_textures(texture_pack_name, square_size)
icon = pygame.transform.smoothscale(textures["title"], (32,32))
pygame.display.set_icon(icon)
state = "title screen"
running = True
skip_first_click = True
world_name = ""
square_selected_id = GRASS
world = player_line = cam = None
min_select_line   = max_select_line   = 0
min_select_column = max_select_column = 0
aera = pygame.Rect(0,0,0,0)
pause_background = pygame.Rect(0,0,w,h)
square_selected = pygame.Rect(w - 20 - square_size*1.5, 20, square_size*1.5, square_size*1.5) 
title = pygame.Rect(w//2-textures["title"].get_width()//2, h//50, 0,  0)
mod = Mod()
copy_memory = []
cursor = Player(0, square_size, 500)
sign_txt = ""
write_sign = False
last_sign = ()
signs_texts = {}
farmings = {}
inventory_square_size = 1.5*square_size
inventory = pygame.Rect(w/2-3.5*inventory_square_size , h/2-2.5*inventory_square_size,
                        8*inventory_square_size, 5*inventory_square_size)
in_inventory = False
pages  = [[[GRASS, DIRT, STONE], [LEAF, TRUNK, PLANKS], [SIGN]],
          [[CHARGER, CABLE, BRIDGE], [AND, OR, XOR], [NOT]]]
current_page = 0
pages_icons = [None, None]
if textures[GRASS] != None:
    pages_icons[0] = pygame.transform.scale(textures[GRASS], (inventory_square_size, inventory_square_size))

if textures[CHARGER] != None:
    pages_icons[1] = pygame.transform.scale(textures[CHARGER], (inventory_square_size, inventory_square_size))

pages_squares = [pygame.Rect(inventory.x-inventory_square_size+1, inventory.y,
                                inventory_square_size,inventory_square_size),
                 pygame.Rect(inventory.x-inventory_square_size+1, inventory.y+inventory_square_size,
                                inventory_square_size, inventory_square_size)]

colors_of_squares = {GRASS: (15, 130, 10),
                     DIRT : (140, 105, 65),
                     STONE: (170, 170, 170),
                     TRUNK: (100, 50, 25),
                     LEAF: (135, 175, 10),
                     CABLE: (255,0,0),
                     CHARGER: (0,255,0),
                     POWERED_CABLE: (0,155,0),
                     AND: (0,0,155),
                     POWERED_AND: (0,0,255),
                     OR: (155,0,155),
                     POWERED_OR: (255,0,255),
                     NOT: (155,155,0),
                     POWERED_NOT: (255,255,0),
                     XOR: (0,155,155),
                     POWERED_XOR: (0,255,255),
                     BRIDGE: (0,0,0),
                     BRIDGE_OFF_ON: (75,75,75),
                     BRIDGE_ON_OFF: (175,175,175),
                     BRIDGE_ON_ON: (255,255,255),
                     PLANKS: (50,20,25),
                     SIGN: (100,40,50)}

##### CREATE BUTTONS #######
new_world_button  = Button(w/2-w/8, w/4, w/4, h/15, "create new world", font)
load_world_button = Button(w/2-w/8, new_world_button.y+new_world_button.h*1.25, w/4, h/15, "load a world", font)
textures_button   = Button(w/2-w/8, load_world_button.y+load_world_button.h*1.25, w/4, h/15, "load a texture pack", font)
switch_keyboard   = SwitchButton(w/2-w/8, textures_button.y+textures_button.h*1.25, w/4, h/15, "pass to azerty", "pass to qwerty", font)
mods_button       = Button(w/2-w/8, switch_keyboard.y+switch_keyboard.h*1.25, w/4, h/15, "load a mod", font)
credits_button    = Button(w/2-w/8, mods_button.y+mods_button.h*1.25, w/4, h/15, "credits", font)
quit_button       = Button(w/2-w/8, credits_button.y+credits_button.h*1.25, w/4, h/15, "quit", font)
continue_button   = Button(w/2-w/8, w/4, w/4, h/15, "continue", font)
save_button       = Button(w/2-w/8, continue_button.y+continue_button.h*1.25, w/4, h/15, "save", font)
save_quit_button  = Button(w/2-w/8, save_button.y+save_button.h*1.25, w/4, h/15, "save and quit", font)
back_button       = pygame.Rect(w/20, h/16, h/15, h/15)

##### CREATE TEXTS #######
name_world_text    = font.render("name of the world:", True, (255,255,255))
error_create_world = font.render("your are limited to 10 worlds", True, (255,255,255))
version_text       = font.render(version, True, (255,255,255))

##### CREATE TEXTS POS #####
world_name_texture_pos = (new_world_button.x,
                          new_world_button.y+new_world_button.h*1.1)
error_create_world_pos = (new_world_button.x+(textures_button.w-error_create_world.get_width())/2,
                          new_world_button.y-new_world_button.h/2)

#### LOAD CCOUNT #####
if not have_account():
    save_account(False, 0, {})

switch_keyboard.condition, play_time, succes = load_account()

while running:
    ####### INPUTS EVENTS ########
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            if state in ("game", "pause"):
                save(world_name, world, cam, signs_texts, farmings)

        elif state == "title screen":
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == LEFT_CLICK:
                    if new_world_button.collidepoint(event.pos):
                        if len(get_worlds()) < 10:
                            world_name = ""
                            state = "naming the world"
                    elif load_world_button.collidepoint(event.pos):
                        state = "load a world"
                    elif textures_button.collidepoint(event.pos):
                        state = "load a texture pack"
                    elif switch_keyboard.collidepoint(event.pos):
                        switch_keyboard.switch()
                    elif credits_button.collidepoint(event.pos):
                        state = "credits"
                    elif mods_button.collidepoint(event.pos):
                        state = "load a mod"
                    elif quit_button.collidepoint(event.pos):
                        running = False
        elif state == "credits":
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == LEFT_CLICK:
                    if back_button.collidepoint(event.pos):
                        state = "title screen"
        elif state == "naming the world":
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == LEFT_CLICK:
                    if new_world_button.collidepoint(event.pos):
                        pygame.display.set_caption(title_window + world_name)
                        world, cam_line = create_world(mod)
                        cam = Player(cam_line-5, square_size, 500)
                        state = "game"
                    elif back_button.collidepoint(event.pos):
                        state = "title screen"
            elif event.type == pygame.KEYDOWN:
                if event.key not in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    if event.key == pygame.K_BACKSPACE:
                        world_name = world_name[:-1]
                    elif len(world_name) < 15:
                        world_name += event.unicode
                else:
                    pygame.display.set_caption(title_window + world_name)
                    world, cam_line = create_world(mod)
                    cam = Player(cam_line-5, square_size, 500)
                    state = "game"
        elif state == "load a world":
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == LEFT_CLICK:
                    if back_button.collidepoint(event.pos):
                        state = "title screen"

                    worlds = get_worlds()
                    for i in range(len(worlds)):
                        button = pygame.Rect(w/2-w/8, 5*w/20+i*h/10, w/4, h/15)
                        delete_button = pygame.Rect(button.x+1.1*button.w, button.y, button.h, button.h)
                        if button.collidepoint(event.pos):
                            world_datas = load(worlds[i])
                            if len(world_datas) > 3:
                                world_name, world, cam, signs_texts, farmings = world_datas
                            else:
                                world_name, world, cam = world_datas
                            pygame.display.set_caption(title_window+world_name)
                            state = "game"
                        elif delete_button.collidepoint(event.pos):
                            delete_world(worlds, i)
        elif state == "load a texture pack":
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == LEFT_CLICK:
                    if back_button.collidepoint(event.pos):
                        state = "title screen"

                list_packs = get_textures_packs()
                for i in range(len(list_packs)):
                    button = pygame.Rect(w/2-w/8, 5*w/20+i*h/10, w/4, h/15)
                    if button.collidepoint(event.pos):
                        textures = load_textures(list_packs[i], square_size)
                        actual_pack = list_packs[i]
                        if textures[GRASS] != None:
                            first_page_icon = pygame.transform.scale(textures[GRASS], (inventory_square_size, inventory_square_size))
                        else:
                            first_page_icon = None
                        if textures[CHARGER] == None:
                            second_page_icon = pygame.transform.scale(textures[CHARGER], (inventory_square_size, inventory_square_size))
                        else:
                            second_page_icon = None
                        state = "title screen"
        elif state == "load a mod":
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == LEFT_CLICK:
                    if back_button.collidepoint(event.pos):
                        state = "title screen"

                list_mods = get_mods()
                last = len(list_mods)
                for i in range(last):
                    button = pygame.Rect(w/2-w/8, 5*w/20+i*h/10, w/4, h/15)
                    if button.collidepoint(event.pos):
                        mod = load_mod("mods/"+list_mods[i], textures)
                        if len(mod.squares) > 0:
                            y = x = shift = 0
                            for i in range(len(mod.squares)):
                                if i % 12 == 0:
                                    x = y = 0
                                    mod_square = pygame.Rect(inventory.x-inventory_square_size+1,
                                                            inventory.y+(i/12+2)*inventory_square_size-shift,
                                                            inventory_square_size, inventory_square_size)
                                    pages_squares.append(mod_square)
                                    if len(pages_squares) % 2 == 0:
                                        shift += 1
                                    if mod.squares[i] in textures and textures[mod.squares[i]] != None:
                                        mod_icon = pygame.transform.scale(textures[mod.squares[i]], (inventory_square_size, inventory_square_size))
                                        pages_icons.append(mod_icon)
                                    else:
                                        pages_icons.append(None)
                                    pages.append([[]])
                                    print(len(pages_icons))
                                else:
                                    if i % 3 == 0:
                                        y = 0
                                        x += 1
                                    else:
                                        y += 1
                                        pages[-1].append([])
                                pages[-1][x].append(i+LAST_ID+1)
                        state = "title screen"

                button = pygame.Rect(w/2-w/8, 5*w/20+last*h/10, w/4, h/15)
                if button.collidepoint(event.pos):
                    mod = Mod()
                    while len(pages_squares) > 2:
                        del pages_squares[-1]
                    state = "title screen"
                
        elif state == "pause":
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    state = "game"
                    skip_first_click = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == LEFT_CLICK:
                    if continue_button.collidepoint(event.pos):
                        state = "game"
                    elif save_button.collidepoint(event.pos):
                        save(world_name, world, cam, signs_texts, farmings)
                    elif save_quit_button.collidepoint(event.pos):
                        save(world_name, world, cam, signs_texts, farmings)
                        square_selected_id = GRASS
                        state = "title screen"
                    elif switch_keyboard.collidepoint(event.pos):
                        switch_keyboard.switch()
        elif state == "game":
            if event.type == pygame.KEYDOWN:
                if write_sign:
                    sign_txt_texture = font.render(sign_txt, True, (255,255,255))
                    if event.key not in (pygame.K_RETURN, pygame.K_KP_ENTER) and (
                       sign_txt_texture.get_width() < square_size*0.8):
                        if event.key == pygame.K_BACKSPACE:
                           sign_txt = sign_txt[:-1]
                        else:
                            sign_txt += event.unicode
                        sign_txt_texture = font.render(sign_txt, True, (255,255,255))
                    else:
                        write_sign = False
                    signs_texts[last_sign] = sign_txt
                else:
                    if event.key == pygame.K_e:
                        in_inventory = not in_inventory
                    elif event.key in (pygame.K_RIGHT, pygame.K_UP):
                        square_selected_id += 1
                        if square_selected_id > LAST_ID + len(mod.squares):
                            square_selected_id = GRASS
                    elif event.key in (pygame.K_LEFT, pygame.K_DOWN):
                        square_selected_id -= 1
                        if square_selected_id < GRASS:
                            square_selected_id = LAST_ID + len(mod.squares)
                    elif event.key == pygame.K_ESCAPE:
                        state = "pause"
                        skip_first_click = True
                    elif event.key == pygame.K_x:
                        cursor.column = (cursor.x + cam.x)//square_size
                        cursor.line = (cursor.y + cam.y)//square_size

                        if (min_select_column != max_select_column) and (
                            min_select_line != max_select_line):
                            if cursor_column < 0:
                                cursor_column = 0

                            if cursor_line < 0:
                                cursor_line = 0
                            elif cursor_line > 99:
                                cursor_line = 99

                            copy_memory = []
                            for line in range(min_select_line, cursor_line+1):
                                copy_memory.append([])
                                l = line-min_select_line
                                for column in range(min_select_column, cursor_column+1):
                                    copy_memory[l].append(world[line][column])
                                    place_square(world, line, column, VOID, signs_texts, farmings)

                            min_select_line = max_select_line = 0
                            min_select_column = max_select_column = 0
                            aera = pygame.Rect(0,0,0,0)
                    elif event.key == pygame.K_c:
                        cursor.column = (cursor.x + cam.x)//square_size
                        cursor.line = (cursor.y + cam.y)//square_size

                        if (min_select_column != max_select_column) and (
                            min_select_line != max_select_line):
                            if cursor_column < 0:
                                cursor_column = 0

                            if cursor_line < 0:
                                cursor_line = 0
                            elif cursor_line > 99:
                                cursor_line = 99

                            copy_memory = []
                            for line in range(min_select_line, cursor_line+1):
                                copy_memory.append([])
                                l = line-min_select_line
                                for column in range(min_select_column, cursor_column+1):
                                    copy_memory[l].append(world[line][column])

                            min_select_line = max_select_line = 0
                            min_select_column = max_select_column = 0
                            aera = pygame.Rect(0,0,0,0)
                    elif event.key == pygame.K_v:
                        cursor.column = (cursor.x + cam.x)//square_size
                        cursor.line = (cursor.y + cam.y)//square_size
                        if (min_select_column != max_select_column) and (
                            min_select_line != max_select_line):
                            cursor_column = min_select_column
                            cursor_line = min_select_line

                        if cursor_column < 0:
                            cursor_column = 0

                        if cursor_line < 0:
                            cursor_line = 0
                        elif cursor_line > 99:
                            cursor_line = 99

                        for line in range(len(copy_memory)):
                            for column in range(len(copy_memory[0])):
                                place_square(world, line+cursor_line, column+cursor_column,
                                             copy_memory[line][column], signs_texts, farmings)

                        min_select_line = max_select_line = 0
                        min_select_column = max_select_column = 0
                        aera = pygame.Rect(0,0,0,0)
                        
            elif event.type == pygame.MOUSEWHEEL:
                if event.y > 0:
                    square_selected_id += 1
                    if square_selected_id > LAST_ID:
                        square_selected_id = GRASS
                else:
                    square_selected_id -= 1
                    if square_selected_id < GRASS:
                        square_selected_id = LAST_ID

            elif event.type == pygame.MOUSEBUTTONDOWN and (
                 event.button in (RIGHT_CLICK, LEFT_CLICK) and (
                 not write_sign)):
                if square_selected.collidepoint(event.pos):
                    in_inventory = not in_inventory
                elif not in_inventory:
                    cursor.x, cursor.y = event.pos
                    cursor.column = (cursor.x + cam.x)//square_size
                    cursor.line = (cursor.y + cam.y)//square_size
                    min_select_column  = cursor.column
                    min_select_line    = cursor.line
                    aera.x = 1
                else:
                    for i in range(len(pages_squares)):
                        if pages_squares[i].collidepoint(event.pos):
                            current_page = i
                            
                    for y in range(len(pages[current_page])):
                        for x in range(len(pages[current_page][y])):
                            inventory_square_id = pages[current_page][y][x]
                            inventory_square = pygame.Rect(inventory.y+inventory_square_size*0.75+y*2*inventory_square_size,
                                                           inventory.x+inventory_square_size/4+x*1.5*inventory_square_size,
                                                           inventory_square_size, inventory_square_size)
                            if inventory_square.collidepoint(event.pos):
                                square_selected_id = inventory_square_id

            elif event.type == pygame.MOUSEBUTTONUP and (
                 event.button in (RIGHT_CLICK, LEFT_CLICK) and (
                 not write_sign)):
                if not in_inventory:
                    if skip_first_click:
                        skip_first_click = False
                    elif aera != pygame.Rect(0,0,0,0):
                        aera = pygame.Rect(0,0,0,0)
                        cursor.x, cursor.y = event.pos
                        cursor.column = (cursor.x + cam.x)//square_size
                        cursor.line = (cursor.y + cam.y)//square_size
                        max_select_column = cursor.column
                        max_select_line   = cursor.line

                        if max_select_column < 0:
                            max_select_column = 0

                        if max_select_line < 0:
                            max_select_line = 0
                        elif max_select_line > 99:
                            max_select_line = 99

                        if max_select_line < min_select_line:
                            max_select_line, min_select_line = min_select_line, max_select_line

                        if max_select_column < min_select_column:
                            max_select_column, min_select_column = min_select_column, max_select_column

                        if event.button == LEFT_CLICK:
                            square = VOID
                            event = BREAK
                        else:
                            square = square_selected_id
                            event = PLACE

                        for line in range(min_select_line, max_select_line+1):
                            for column in range(min_select_column, max_select_column+1):
                                place_square(world, line, column, square, signs_texts, farmings)

                        if world[line][column] == SIGN:
                            sign_txt = ""
                            write_sign = True
                            last_sign = (line, column)

                        execute_mod_event(event, mod, world, (min_select_line, min_select_column), (max_select_line, max_select_column))

                        min_select_line   = max_select_line   = 0
                        min_select_column = max_select_column = 0             

    #### RUNNING GAME #####
    if state == "game":
        delta_time = clock.tick() / 1000

        play_time += delta_time

        keys = pygame.key.get_pressed()

        if not write_sign:
            cam.update(delta_time, square_size, world, render_distance, switch_keyboard.condition, keys)

            cursor.x, cursor.y = pygame.mouse.get_pos()
            cursor.column = (cursor.x + cam.x)//square_size
            cursor.line = (cursor.y + cam.y)//square_size
            
            if (min_select_column != max_select_column) and (
                min_select_line != max_select_line):
                if cursor.column < 0:
                    cursor.column = 0

                if cursor.line < 0:
                    cursor.line = 0
                elif cursor.line > 99:
                    cursor.line = 99

                if cursor.column < min_select_column:
                    aera.x = cursor.column*square_size - cam.x
                    aera.w = min_select_column*square_size - aera.x + square_size - cam.x
                else:
                    aera.x = min_select_column*square_size - cam.x
                    aera.w = cursor.column*square_size - aera.x + square_size - cam.x

                if cursor.line < min_select_line:
                    aera.y = cursor.line*square_size - cam.y
                    aera.h = min_select_line*square_size - aera.y + square_size - cam.y
                else:
                    aera.y = min_select_line*square_size - cam.y
                    aera.h = cursor.line*square_size - aera.y + square_size - cam.y
            else:
                aera = pygame.Rect(0,0,0,0)
        
        column_started = cam.x//square_size
        column_finish = cam.x//square_size + render_distance
        line_started = cam.y//square_size
        line_finish = cam.y//square_size + render_distance

        if line_finish > 99:
            line_finish = 99

        if column_finish >= len(world[0]):
            generate(world, 100, mod)

        execute_elecity(world, column_started, column_finish, line_started, line_finish)

#### DRAWIING ####
    if state == "game":
        window.fill((75, 190, 245))

        draw(window, mod, textures,
             colors_of_squares, world, column_started, column_finish,
             line_started, line_finish, cam, signs_texts, font)

        gfxdraw.box(window, aera, (220,220,220,120))
        pygame.draw.rect(window, (230,230,230), aera, 3)

        if square_selected_id <= LAST_ID:
            if textures[square_selected_id] != None:
                texture = pygame.transform.scale(textures[square_selected_id], (square_size*1.5, square_size*1.5))
                window.blit(texture, square_selected)
            else:
                color_selected = colors_of_squares[square_selected_id]
                pygame.draw.rect(window, color_selected, square_selected)
        else:
            square = mod.squares[square_selected_id-LAST_ID-1]
            if square in textures and textures[square] != None:
                texture = pygame.transform.scale(textures[square], (square_size*1.5, square_size*1.5))
                window.blit(texture, square_selected)
            else:
                pygame.draw.rect(window, (255,0,255), square_selected)
        pygame.draw.rect(window, (0,0,0), square_selected, 5)

        if in_inventory:
            pygame.draw.rect(window, (255,255,255), inventory)
            for y in range(len(pages[current_page])):
                for x in range(len(pages[current_page][y])):
                    inventory_square_id = pages[current_page][y][x]
                    inventory_square = pygame.Rect(inventory.y+inventory_square_size*0.75+y*2*inventory_square_size,
                                                   inventory.x+inventory_square_size/4+x*1.5*inventory_square_size,
                                                   inventory_square_size, inventory_square_size)
                    if inventory_square_id not in textures or textures[inventory_square_id] == None:
                        if inventory_square_id in colors_of_squares:
                            color = colors_of_squares[inventory_square_id]
                        else:
                            color = (255,0,255)
                            pygame.draw.rect(window, color, inventory_square)
                    else:
                        resize = pygame.transform.scale(textures[inventory_square_id],
                                                        (inventory_square_size, inventory_square_size))
                        window.blit(resize, inventory_square)
                    pygame.draw.rect(window, (0,0,0), inventory_square, 3)
            for i in range(len(pages_icons)):
                if pages_icons[i] == None:
                    pygame.draw.rect(window, (255,0,255), pages_squares[i])
                else:
                    window.blit(pages_icons[i], pages_squares[i])
            pygame.draw.rect(window, (0,0,0), pages_squares[current_page], 4)

    elif state not in ("pause", "sign"):
        window.fill((0,0,0))

        window.blit(version_text, (w*0.05, h*0.85))

        if textures["title"] != None:
            window.blit(textures["title"], title)

    if state == "title screen":
        new_world_button.draw(textures, window)
        load_world_button.draw(textures, window)
        textures_button.draw(textures, window)
        switch_keyboard.draw(textures, window)
        mods_button.draw(textures, window)
        credits_button.draw(textures, window)
        quit_button.draw(textures, window)

    elif state == "pause":
        window.fill((75, 190, 245))

        draw(window, mod, textures,
             colors_of_squares, world, column_started, column_finish,
             line_started, line_finish, cam, signs_texts, font)

        gfxdraw.box(window, pause_background, (20,20,20,170))

        if textures["title"] != None:
            window.blit(textures["title"], title)

        continue_button.draw(textures, window)
        save_button.draw(textures, window)
        save_quit_button.draw(textures, window)
        switch_keyboard.draw(textures, window)

        pos = (font.render(f"{cam.x=}", True, (255,255,255)),
                font.render(f"{cam.y=}", True, (255,255,255)),
                font.render(f"{cam.column=}", True, (255,255,255)),
                font.render(f"{cam.line=}", True, (255,255,255)))


        mins = play_time/60
        hours = int(mins/60)
        mins -= 60*hours
        mins = int(mins)

        if hours < 10:
            hours = f"0{hours}"

        if mins < 10:
            mins = f"0{mins}"
            
        time = font.render(f"play time: {hours}h{mins}", True, (255,255,255))
        
        for i in range(len(pos)):
            window.blit(pos[i], (10, 15+i*20))

        window.blit(time, (w*0.05, h*0.85))        

    elif state == "credits":
        if textures["back"] != None:
            window.blit(textures["back"], back_button)
        else:
            pygame.draw.rect(window, (200,200,200), back_button)

        for i in range(len(credits)):
            window.blit(credits[i], ((w-credits[i].get_width())//2, i*h//20+w//4))

    elif state == "naming the world":
        if textures["back"] != None:
            window.blit(textures["back"], back_button)
        else:
            pygame.draw.rect(window, (200,200,200), back_button)
        new_world_button.draw(textures, window)

        world_name_texture = font.render(" "+world_name+" ", True, (0,0,0), (220,220,220))
        window.blit(world_name_texture, world_name_texture_pos)
        window.blit(error_create_world, error_create_world_pos)

    elif state == "load a world":
        if textures["back"] != None:
            window.blit(textures["back"], back_button)
        else:
            pygame.draw.rect(window, (200,200,200), back_button)

        worlds = get_worlds()
        for i in range(len(worlds)):
            button = Button(w/2-w/8, 5*w/20+i*h/10, w/4, h/15, worlds[i][:-4], font)
            delete_button = pygame.Rect(button.x+1.1*button.w, button.y, button.h, button.h)
            button.draw(textures, window)
            if textures["delete"] != None:
                window.blit(textures["delete"], delete_button)
            else:
                pygame.draw.rect(window, (200,200,200), delete_button)

    elif state == "load a texture pack":
        if textures["back"] != None:
            window.blit(textures["back"], back_button)
        else:
            pygame.draw.rect(window, (200,200,200), back_button)

        list_packs = get_textures_packs()
        for i in range(len(list_packs)):
            button = Button(w/2-w/8, 5*w/20+i*h/10, w/4, h/15, list_packs[i], font)
            button.draw(textures, window)

    elif state == "load a mod":
        if textures["back"] != None:
            window.blit(textures["back"], back_button)
        else:
            pygame.draw.rect(window, (200,200,200), back_button)

        list_mods = get_mods()
        last = len(list_mods)
        for i in range(last):
            button = Button(w/2-w/8, w/4+i*h/10, w/4, h/15, list_mods[i], font)
            button.draw(textures, window)
        button = Button(w/2-w/8, w/4+last*h/10, w/4, h/15, "no mods", font)
        button.draw(textures, window)

    pygame.display.flip()

save_account(switch_keyboard.condition, play_time, play_time)
pygame.quit()

if have_update(URL_TEXTURES_VERSION):
    textures_update()

if have_update(URL_VERSION):
    update()
